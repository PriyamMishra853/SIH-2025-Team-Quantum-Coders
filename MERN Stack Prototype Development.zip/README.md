
  # MERN Stack Prototype Development

  This is a code bundle for MERN Stack Prototype Development. The original project is available at https://www.figma.com/design/23ud6Vgi4cESeZZlRusyPv/MERN-Stack-Prototype-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  